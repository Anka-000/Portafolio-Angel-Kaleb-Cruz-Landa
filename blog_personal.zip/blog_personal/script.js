// La "Base de Datos" de Reseñas
// Para añadir una nueva reseña:
// Se crea un nuevo archivo .html para la reseña (nombrado con el id) y se guarda en la carpeta reseñas
// Se añade un nuevo objeto al principio de este array
// Y se configura el enlace (link) para que apunte a ese nuevo archivo
window.reviewsDB = [
    {
        //Se le configura un id y el titulo que aparecera en la tarjeta
        id: 'cp2077-pl',
        title: 'Cyberpunk 2077: Phantom Liberty',
        //Especificamos la fecha de la publicacion
        date: '2024-10-01',
        //Agregamos una breve descripcion de la reseña para la tarjeta
        description: 'Un análisis profundo de la expansión que cambió el juego por completo...',
        //Agregamos la imagen principal y la de hover que usara usando los links directos
        image: 'https://p325k7wa.twic.pics/high/cyberpunk/cyberpunk-2077/00-page-setup/cp2077_game-thumbnail.jpg?twic=v1/resize=760/step=10/quality=80',
        imageHover: 'https://polvora.com.mx/wp-content/uploads/2020/11/CP2.jpg',
        //Agregamos el enlace al documento HMTL de la reseña
        link: 'reseñas/cyberpunk-2077.html' 
    },//Se usa la misma logica para las demas reseñas
    {
        id: 'bg3',
        title: "Baldur's Gate 3",
        date: '2024-09-15',
        description: '¿Es este el mejor RPG de la década? Te contamos todo sobre el coloso de Larian Studios.',
        image: 'https://www.nextgame.es/wp-content/uploads/2024/01/NextGame-Baldurs-Gate-3.jpg',
        imageHover: 'https://www.rpgnuke.ru/wp-content/uploads/2023/11/Baldurs-Gate-3-345345423423234223435343453453453434543.jpg',
        link: 'reseñas/baldurs-gate-3.html'
    },
    {
        id: 'aw2',
        title: 'Alan Wake 2',
        date: '2024-09-02',
        description: 'Una joya del survival horror que juega con tu mente. Analizamos su narrativa y jugabilidad.',
        image: 'https://cdn1.epicgames.com/offer/c4763f236d08423eb47b4c3008779c84/EGS_AlanWake2_RemedyEntertainment_S1_2560x1440-ec44404c0b41bc457cb94cd72cf85872?resize=1&w=480&h=270&quality=medium',
        imageHover: 'https://cdn.hobbyconsolas.com/sites/navi.axelspringer.es/public/media/image/2023/10/alan-wake-2-3206290.jpg?tf=3840x',
        link: 'reseñas/alan-wake-2.html' 
    },
    {
        id: 'zelda-totk',
        title: 'Tears of the Kingdom',
        date: '2024-08-20',
        description: 'Nintendo lo ha vuelto a hacer. Exploramos la inmensa Hyrule y sus nuevas mecánicas.',
        image: 'https://gaming-cdn.com/images/news/articles/8134/cover/1000x563/nintendo-situa-breath-of-the-wild-y-tears-of-the-kingdom-fuera-de-la-linea-temporal-ya-existente-de-zelda-cover66d580afaae42.jpg',
        imageHover: 'https://m.media-amazon.com/images/I/61kt7nbNy9L._UF1000,1000_QL80_.jpg',
        link: 'reseñas/zelda-totk.html' 
    },
    {
        id: 'p3',
        title: 'Persona 3 Reload',
        date: '2024-07-20',
        description: 'Un clasico reinventado para la nueva generacion, una historia encantadora sobre la belleza de la vida',
        image: 'https://personacentral.com/wp-content/uploads/2023/06/P3R-Key-Art.jpg',
        imageHover: 'https://image.api.playstation.com/vulcan/ap/rnd/202307/2605/19353f11f85964dd2be8eae4564a0e78b011a81824d9b4a9.png',
        link: 'reseñas/persona-3-reload.html' 
    },
    {
        id: 'metaphor',
        title: 'Metaphor: ReFantasia',
        date: '2024-06-20',
        description: 'De los mismos creadores de la saga Persona y SMT. Un viaje surrealista para convertirse en rey de ucronia.',
        image: 'https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/2679460/capsule_616x353.jpg?t=1759872361',
        imageHover: 'https://cdn.hobbyconsolas.com/sites/navi.axelspringer.es/public/media/image/2024/10/metaphor-refantazio-4251322.jpg?tf=3840x',
        link: 'reseñas/metaphor-refantasia.html' 
    },
    {
        id: 'tlda',
        title: 'The hundred line: Last Defense Academy',
        date: '2024-06-01',
        description: 'Un JRPG tactico con una historia profunda y un sistema de combate adictivo. Con 100 finales distintos',
        image: 'https://gamingtrend.com/content/images/size/w1200/2025/02/screenshot-5--1-1.jpeg',
        imageHover: 'https://assetsio.gnwcdn.com/ss_13baa96c1d9bb764498a1c80f452945d84d47372.1920x1080.jpg?width=690&quality=80&format=jpg&dpr=3&auto=webp',
        link: 'reseñas/the-hundred-line-last-defense-academy.html' 
    },
    //Aqui se pueden añadir más reseñas siguiendo el mismo formato
];


// Funcion para el efecto hover en las imagenes de las tarjetas
function setupImageHover() {
    // Seleccionamos todas las imágenes dentro de las tarjetas de reseña
    const reviewImages = document.querySelectorAll('.review-card img');
    reviewImages.forEach(image => {
        // Evento para cuando el ratón entra en la imagen
        image.addEventListener('mouseover', () => {
            image.src = image.dataset.hoverImage; // Cambia a la imagen de hover
        });

        // Evento para cuando el ratón sale de la imagen
        image.addEventListener('mouseout', () => {
            image.src = image.dataset.originalImage; // Vuelve a la imagen original
        });
    });
}


//Listener para mostrar mas reseñas luego de hacer click en el boton
document.addEventListener('DOMContentLoaded', () => {
    //Se verifica si existe un contenedor con id 'reviews-container' para saber si estamos en la pagina de todas las reseñas
    if (document.getElementById('reviews-container')) {
        //Contenedor donde se incetara las reseñas dinamicamente
        const reviewsContainer = document.getElementById('reviews-container');
        //Contenedor para el boton de cargar mas
        const loadMoreContainer = document.getElementById('load-more-container');
        // Cantidad de reseñas que se mostrarán cada vez que el usuario haga clic en el boton cargar mas
        let reviewsToShow = 3;
        // Contador para llevar registro de cuántas reseñas ya se mostraron
        let reviewsShown = 0;

        // Función encargada de renderizar las reseñas en el DOM
        function renderReviews() {
            // Obtiene una porción de reseñas desde reviewsDB
            const reviewsToRender = reviewsDB.slice(reviewsShown, reviewsShown + reviewsToShow);
            // Por cada reseña seleccionada, se genera una estructura HTML y se agrega al contenedor principal usando sus caracteristicas definidas con antelacion
            reviewsToRender.forEach(review => {
                const reviewCardHTML = `
                    <article class="review-card">
                        <img 
                            src="${review.image}" 
                            data-original-image="${review.image}"
                            data-hover-image="${review.imageHover}"
                            alt="Imagen de ${review.title}">
                        <div class="card-content">
                            <h4>${review.title}</h4>
                            <p>${review.description}</p>
                            <a href="${review.link}">Ver más</a>
                        </div>
                    </article>
                `;
                // Se añade la tarjeta al final del contenedor sin borrar las anteriores
                reviewsContainer.innerHTML += reviewCardHTML;
            });

            // Se actualiza el contador de reseñas ya mostradas
            reviewsShown += reviewsToRender.length;

            // Si ya no hay más reseñas por mostrar, se elimina el botón "Cargar Más"
            if (reviewsShown >= reviewsDB.length) {
                loadMoreContainer.innerHTML = '';
                // Si aún hay más reseñas y no existe un botón, se crea uno y se le agrega un listener
            } else if (!document.getElementById('load-more-btn')) {
                 loadMoreContainer.innerHTML = '<button id="load-more-btn" class="btn">Cargar Más</button>';
                 // Al hacer clic en el botón, se vuelve a ejecutar esta función para cargar más reseñas
                 document.getElementById('load-more-btn').addEventListener('click', renderReviews);
            }
            
            // Llamamos a la función de hover despues de crear las tarjetas
            setupImageHover();
        }
        // Se llama a la función una vez al cargar la página para mostrar las primeras reseñas
        renderReviews();
    }

    // Simplemente llamamos a la función para que se aplique a las tarjetas que ya existen en el HTML
    setupImageHover(); 
});
