<?php
/*
 * Archivo: conexion.php
 * Se encarga de establecer la conexión con la base de datos MySQL.
 */

// Parámetros de la base de datos
$db_host = "localhost:3322"; // El servidor donde está la BD (en XAMPP )
$db_user = "root";      // El usuario de la BD (en XAMPP es 'root')
$db_pass = "";          // La contraseña (en XAMPP por defecto es vacía)
$db_name = "blog_db";   // El nombre de la base de datos que creamos

// REQUISITO: Conectarse desde PHP usando mysqli
// Creamos el objeto de conexión
$conexion = new mysqli($db_host, $db_user, $db_pass, $db_name);

// REQUISITO: Verificar la conexión (como en tu ejemplo)
if ($conexion->connect_error) {
    // Si hay un error, el script se detiene y muestra el error.
    die("Error de conexión: " . $conexion->connect_error);
}

// Establecemos el juego de caracteres a UTF-8
// Esto es muy importante para que las tildes y 'ñ' se guarden y muestren bien.
$conexion->set_charset("utf8mb4");

// Si llegamos aquí, la conexión fue exitosa.
// Dejamos la variable $conexion lista para que otros scripts la usen.
?>