<?php
/*
 * Archivo: clase_basedatos.php
 * Clase BaseDatos para conexión y consultas.
 */

class BaseDatos {
    
    // Propiedades de la conexión
    private $host;
    private $db_user;
    private $db_pass;
    private $db_name;
    private $port;

    // Propiedad para el objeto de conexión
    public $conexion; // La hacemos pública para que otras clases la usen

    public function __construct() {
        // Obtenemos los datos del archivo de conexión
        // Usamos los mismos datos que ya tenías en conexion.php
        $this->host = "localhost:3322"; // <-- ¡IMPORTANTE! Usa tu puerto (3322)
        $this->db_user = "root";
        $this->db_pass = "";
        $this->db_name = "blog_db";
    }

    // Método para conectar
    public function conectar() {
        // Creamos la conexión
        $this->conexion = new mysqli($this->host, $this->db_user, $this->db_pass, $this->db_name);

        // Verificamos si hay error
        if ($this->conexion->connect_error) {
            die("Error de conexión: " . $this->conexion->connect_error);
        }

        // Establecemos el charset para tildes y eñes
        $this->conexion->set_charset("utf8mb4");
    }

    // Método para desconectar
    public function desconectar() {
        if ($this->conexion) {
            $this->conexion->close();
        }
    }

    // Método de ayuda para obtener la conexión
    // (Útil para que otras clases la pidan)
    public function getConexion() {
        return $this->conexion;
    }
}
?>