<?php
/*
 * Archivo: clase_mensaje.php
 * Clase 'Publicacion' (la llamamos Mensaje) 
 * con métodos crear(), leer(), actualizar(), eliminar().
 */

class Mensaje {
    
    // Propiedades del mensaje
    public $id;
    public $titulo;
    public $contenido;
    public $correo;
    public $fecha;

    // Propiedad para la conexión
    private $db; // Almacenará el objeto BaseDatos

    // El constructor recibe la conexión a la BD
    public function __construct(BaseDatos $db) {
        $this->db = $db;
    }

    // MÉTODO CREAR()
    public function crear($titulo, $contenido, $correo) {
        $conn = $this->db->getConexion(); // Obtenemos la conexión mysqli
        $fecha_actual = date('Y-m-d H:i:s');
        
        $sql = "INSERT INTO mensajes (titulo, contenido, correo, fecha) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $titulo, $contenido, $correo, $fecha_actual);
        
        $resultado = $stmt->execute();
        $stmt->close();
        
        return $resultado; // Devuelve true si tuvo éxito, false si no
    }

    // MÉTODO LEER() (Leer un solo mensaje)
    public function leer($id) {
        $conn = $this->db->getConexion();
        
        $sql = "SELECT * FROM mensajes WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id); // 'i' porque el ID es un entero
        $stmt->execute();
        
        $resultado = $stmt->get_result(); // Obtenemos los resultados
        
        if ($resultado->num_rows == 1) {
            $fila = $resultado->fetch_assoc();
            // Llenamos las propiedades de este objeto con los datos
            $this->id = $fila['id'];
            $this->titulo = $fila['titulo'];
            $this->contenido = $fila['contenido'];
            $this->correo = $fila['correo'];
            $this->fecha = $fila['fecha'];
            
            $stmt->close();
            return true;
        }
        
        $stmt->close();
        return false; // No se encontró el mensaje
    }

    // MÉTODO ACTUALIZAR()
    public function actualizar($id, $titulo, $contenido, $correo) {
        $conn = $this->db->getConexion();
        
        $sql = "UPDATE mensajes SET titulo = ?, contenido = ?, correo = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $titulo, $contenido, $correo, $id);
        
        $resultado = $stmt->execute();
        $stmt->close();
        
        return $resultado;
    }

    // MÉTODO ELIMINAR()
    public function eliminar($id) {
        $conn = $this->db->getConexion();
        
        $sql = "DELETE FROM mensajes WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        
        $resultado = $stmt->execute();
        $stmt->close();
        
        return $resultado;
    }

    // OBTENER TODOS (Para la lista principal)
    // Lo hacemos 'static' para poder llamarlo sin crear un objeto
    public static function obtenerTodos(BaseDatos $db) {
        $conn = $db->getConexion();
        $sql = "SELECT * FROM mensajes ORDER BY fecha DESC";
        $resultado = $conn->query($sql);
        
        $mensajes = []; // Array para guardar los mensajes
        if ($resultado->num_rows > 0) {
            while($fila = $resultado->fetch_assoc()) {
                $mensajes[] = $fila; // Añadimos la fila al array
            }
        }
        return $mensajes;
    }
}
?>