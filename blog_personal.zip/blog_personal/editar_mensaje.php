<?php
// Incluimos las clases
require_once('clase_basedatos.php');
require_once('clase_mensaje.php');

// Conectamos a la BD
$bd = new BaseDatos();
$bd->conectar();
$mensaje = new Mensaje($bd); // Objeto para usar los métodos

$id_mensaje = 0;

//LÓGICA DE ACTUALIZACIÓN
// 1. VERIFICAR SI EL FORMULARIO FUE ENVIADO (MÉTODO POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Tomamos los datos del formulario
    $id = (int)$_POST['id'];
    $titulo = $_POST['titulo'];
    $contenido = $_POST['contenido'];
    $correo = $_POST['correo'];
    
    // Llamamos al método actualizar
    $mensaje->actualizar($id, $titulo, $contenido, $correo);
    
    // Redirigimos a la lista principal
    header("Location: gestionar_mensajes.php?status=actualizado");
    exit;
}

// LÓGICA DE CARGA DE DATOS (READ) 
// 2. SI NO ES POST, ES QUE QUIERE CARGAR LOS DATOS (MÉTODO GET)
if (isset($_GET['id'])) {
    $id_mensaje = (int)$_GET['id'];
    
    // Usamos el método leer() para cargar los datos en el objeto $mensaje
    if (!$mensaje->leer($id_mensaje)) {
        // Si leer() devuelve false, el mensaje no existe
        die("Mensaje no encontrado.");
    }
} else {
    die("No se ha especificado un ID de mensaje.");
}

// Desconectamos la BD al final
$bd->desconectar();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Mensaje - Mi Blog</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        .form-group {
            margin-bottom: 1.5rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
        }
        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid var(--color-secondary);
            background-color: var(--color-surface);
            color: var(--color-text);
            font-family: var(--font-main);
        }
        .form-group textarea {
            min-height: 200px;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <a href="index.html" class="logo">GameReview</a>
            <nav>
                <ul>
                    <li><a href="index.html">Inicio</a></li>
                    <li><a href="sobre-mi.html">Sobre Mí</a></li>
                    <li><a href="todas-las-reseñas.html">Todas las Reseñas</a></li>
                    <li><a href="gestionar_mensajes.php">Gestionar Mensajes</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="container" style="padding-top: 3rem; padding-bottom: 3rem; max-width: 800px;">
            <h2>Editar Mensaje #<?php echo $mensaje->id; ?></h2>
            
            <form action="editar_mensaje.php" method="POST" style="margin-top: 2rem;">
                
                <input type="hidden" name="id" value="<?php echo $mensaje->id; ?>">
                
                <div class="form-group">
                    <label for="titulo">Título:</label>
                    <input type="text" id="titulo" name="titulo" value="<?php echo htmlspecialchars($mensaje->titulo); ?>" required>
                </div>

                <div class="form-group">
                    <label for="correo">Correo Electrónico:</label>
                    <input type="email" id="correo" name="correo" value="<?php echo htmlspecialchars($mensaje->correo); ?>" required>
                </div>

                <div class="form-group">
                    <label for="contenido">Mensaje:</label>
                    <textarea id="contenido" name="contenido" rows="10" required><?php echo htmlspecialchars($mensaje->contenido); ?></textarea>
                </div>

                <button type="submit" class="btn">Actualizar Mensaje</button>
                <a href="gestionar_mensajes.php" class="btn" style="background-color: #555; margin-left: 10px;">Cancelar</a>
            </form>
        </section>
    </main>
    
    <footer style="background-color: var(--color-surface); text-align: center; padding: 2rem 0; margin-top: 2rem; border-top: 2px solid var(--color-secondary);">
        <p>&copy; 2025 GameReview. Todos los derechos reservados.</p>
    </footer>
</body>
</html>