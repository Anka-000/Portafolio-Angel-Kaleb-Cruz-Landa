<?php
// 1. Incluimos las NUEVAS clases
require_once('clase_basedatos.php'); 
require_once('clase_mensaje.php');

// 2. Conectamos a la BD usando la clase
$bd = new BaseDatos();
$bd->conectar();

// Establecer la codificación de caracteres
header('Content-Type: text/html; charset=utf-8');

// Variables para la respuesta
$respuesta_personalizada = "";
$info_servidor = "";

// Comprobamos si la solicitud se envió usando POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Obtenemos datos (como antes)
    $nombre_post = htmlspecialchars($_POST['nombre']);
    $correo_post = htmlspecialchars($_POST['correo']);
    $celular_post = isset($_POST['celular']) && !empty($_POST['celular']) ? htmlspecialchars($_POST['celular']) : "No proporcionado";
    $mensaje_post = htmlspecialchars($_POST['mensaje']);

    // Adaptamos datos
    $titulo_para_clase = "Mensaje de: " . $nombre_post;
    $contenido_para_clase = $mensaje_post;

    // 3. ¡AQUÍ ESTÁ EL CAMBIO!
    // Usamos las nuevas clases para el método CREAR
    $mensaje = new Mensaje($bd); // Creamos el objeto
    $exito = $mensaje->crear(
        $titulo_para_clase, 
        $contenido_para_clase, 
        $correo_post
    );

    // 4. Cerramos la conexión
    $bd->desconectar();

    // 5. Preparamos la respuesta (ya no usamos el método mostrar()
    // porque ahora es una respuesta simple de confirmación)
    if ($exito) {
        $respuesta_personalizada = "<h1>¡Gracias por contactarme, " . $nombre_post . "!</h1>
                                 <p>Tu mensaje ha sido guardado en la Base de Datos.</p>
                                 <hr style='margin: 1.5rem 0; border-color: var(--color-surface);'>
                                 <p><strong>Correo:</strong> " . $correo_post . "</p>
                                 <p><strong>Celular:</strong> " . $celular_post . "</p>";
    } else {
        $respuesta_personalizada = "<h1>Error</h1><p>Hubo un problema al guardar tu mensaje. Inténtalo de nuevo.</p>";
    }
    
    // La info del servidor se queda igual
    $info_servidor = "<h2>Información del Servidor (\$_SERVER)</h2>
                     <ul style='list-style-type: none; padding-left: 0;'>
                        <li><strong>Software del Servidor:</strong> " . $_SERVER['SERVER_SOFTWARE'] . "</li>
                        <li><strong>Método de Petición:</strong> " . $_SERVER['REQUEST_METHOD'] . "</li>
                        <li><strong>Tu Dirección IP:</strong> " . $_SERVER['REMOTE_ADDR'] . "</li>
                     </ul>";

} else {
    // Si alguien intenta acceder al script directamente
    $respuesta_personalizada = "<h1>Acceso no válido</h1>
                             <p>Por favor, envía el formulario desde la página de contacto.</p>";
    $info_servidor = "<p>Se detectó un método de acceso: " . $_SERVER['REQUEST_METHOD'] . "</p>";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Respuesta del Servidor</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        .mensaje-mostrado {
            background-color: var(--color-surface);
            border: 1px solid var(--color-primary);
            padding: 1.5rem;
            border-radius: 8px;
            margin-top: 1.5rem;
        }
        .mensaje-mostrado h2 {
            margin: 0 0 0.5rem 0;
            color: var(--color-primary);
        }
        .mensaje-mostrado small {
            display: block;
            margin-top: 1rem;
            opacity: 0.7;
        }
        .mensaje-mostrado p strong {
            color: var(--color-text);
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <a href="index.html" class="logo">GameReview</a>
            <nav>
                <ul>
                    <li><a href="index.html">Inicio</a></li>
                    <li><a href="sobre-mi.html">Sobre Mí</a></li>
                    <li><a href="todas-las-reseñas.html">Todas las Reseñas</a></li>
                    <li><a href="gestionar_mensajes.php">Gestionar Mensajes</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="container" style="padding-top: 3rem; padding-bottom: 3rem; max-width: 800px;">
            <?php echo $respuesta_personalizada; ?>
            <hr style="margin: 2rem 0; border-color: var(--color-surface);">
            <?php echo $info_servidor; ?>
            <a href="sobre-mi.html" class="btn" style="margin-top: 2rem;">Volver al formulario</a>
        </section>
    </main>
    
    <footer style="background-color: var(--color-surface); text-align: center; padding: 2rem 0; margin-top: 2rem; border-top: 2px solid var(--color-secondary);">
        <p>&copy; 2025 GameReview. Todos los derechos reservados.</p>
    </footer>

</body>
</html>