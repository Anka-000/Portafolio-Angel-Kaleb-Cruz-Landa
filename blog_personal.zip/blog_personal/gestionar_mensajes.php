<?php
// Incluimos las nuevas clases
require_once('clase_basedatos.php');
require_once('clase_mensaje.php');

// Conectamos a la BD
$bd = new BaseDatos();
$bd->conectar();

// LÓGICA PARA GESTIONAR ACCIONES
$mensaje_clase = new Mensaje($bd); // Creamos un objeto para usar sus métodos

// 1. COMPROBAR SI SE QUIERE ELIMINAR
if (isset($_GET['accion']) && $_GET['accion'] == 'eliminar' && isset($_GET['id'])) {
    $id_a_eliminar = (int)$_GET['id'];
    $mensaje_clase->eliminar($id_a_eliminar);
    
    // Redirigimos a la misma página para limpiar la URL
    header("Location: gestionar_mensajes.php?status=eliminado");
    exit;
}

// 2. OBTENER TODOS LOS MENSAJES (LEER)
$lista_mensajes = Mensaje::obtenerTodos($bd);

// 3. DESCONECTAR (la consulta ya se hizo)
$bd->desconectar();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Mensajes - Mi Blog</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        /* Estilos para la tabla de gestión */
        .gestion-tabla {
            width: 100%;
            border-collapse: collapse;
            margin-top: 2rem;
            color: var(--color-text);
        }
        .gestion-tabla th, .gestion-tabla td {
            border: 1px solid var(--color-surface);
            padding: 10px 15px;
            text-align: left;
        }
        .gestion-tabla th {
            background-color: var(--color-surface);
            font-weight: 600;
        }
        .gestion-tabla tr:nth-child(even) {
            background-color: #1f2937a1; /* Fondo ligeramente diferente */
        }
        .accion-btn {
            padding: 5px 10px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 0.9rem;
            margin-right: 5px;
        }
        .btn-editar {
            background-color: var(--color-secondary);
            color: var(--color-text);
        }
        .btn-eliminar {
            background-color: #DC2626; /* Rojo */
            color: var(--color-text);
        }
        .status-msg {
            background-color: #16A34A; /* Verde */
            color: white;
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>

    <header>
        <div class="container">
            <a href="index.html" class="logo">GameReview</a>
            <nav>
                <ul>
                    <li><a href="index.html">Inicio</a></li>
                    <li><a href="sobre-mi.html">Sobre Mí</a></li>
                    <li><a href="todas-las-reseñas.html">Todas las Reseñas</a></li>
                    <li><a href="gestionar_mensajes.php">Gestionar Mensajes</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="container" style="padding-top: 3rem; padding-bottom: 3rem; max-width: 1000px;">
            <h2>Gestión de Mensajes</h2>
            <p>Aquí puedes ver, editar y eliminar los mensajes recibidos.</p>

            <?php if (isset($_GET['status']) && $_GET['status'] == 'eliminado'): ?>
                <div class="status-msg">Mensaje eliminado correctamente.</div>
            <?php endif; ?>
            <?php if (isset($_GET['status']) && $_GET['status'] == 'actualizado'): ?>
                <div class="status-msg">Mensaje actualizado correctamente.</div>
            <?php endif; ?>

            <table class="gestion-tabla">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Título</th>
                        <th>Correo</th>
                        <th>Fecha</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($lista_mensajes) > 0): ?>
                        <?php foreach ($lista_mensajes as $msg): ?>
                            <tr>
                                <td><?php echo $msg['id']; ?></td>
                                <td><?php echo htmlspecialchars($msg['titulo']); ?></td>
                                <td><?php echo htmlspecialchars($msg['correo']); ?></td>
                                <td><?php echo $msg['fecha']; ?></td>
                                <td>
                                    <a href="editar_mensaje.php?id=<?php echo $msg['id']; ?>" class="accion-btn btn-editar">Editar</a>
                                    <a href="gestionar_mensajes.php?accion=eliminar&id=<?php echo $msg['id']; ?>" 
                                       class="accion-btn btn-eliminar"
                                       onclick="return confirm('¿Estás seguro de que quieres eliminar este mensaje?');">
                                       Eliminar
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" style="text-align: center;">No hay mensajes para mostrar.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            
        </section>
    </main>
    
    <footer style="background-color: var(--color-surface); text-align: center; padding: 2rem 0; margin-top: 2rem; border-top: 2px solid var(--color-secondary);">
        <p>&copy; 2025 GameReview. Todos los derechos reservados.</p>
    </footer>

</body>
</html>